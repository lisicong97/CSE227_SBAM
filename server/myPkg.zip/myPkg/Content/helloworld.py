def foo():
    print("Helloworld")
foo()